<?php
error_reporting(0);
//==========================// token //==========================//
define('API_KEY', '8412922567:AAHBrA7k0P6d81LoGgBxKc9yic_oEGVWqPw');
define('API_URL', 'https://api.telegram.org/bot' . API_KEY . '/');
//==========================// config //==========================//
$admin    = "8421119067";
$group_log    = "-1004376019571";

$usernamebot  = "HashTccCheckerBot";
$channel = "DvixTimes";
$bug_report = "im_dvix";

$web = "https://aminifo.s2026h.space/s";
$api = "https://api.spcloud.online";
//==========================// database //==========================//
$dbname = "hatjmt_xhdhdhdhdh";
$dbuser = "hatjmt_xhdhdhdhdh";
$dbpass = "hatjmt_xhdhdhdhdh";

$connect = new mysqli('localhost', $dbuser, $dbpass, $dbname);
$connect->query("SET NAMES 'utf8'");
$connect->set_charset('utf8mb4');
